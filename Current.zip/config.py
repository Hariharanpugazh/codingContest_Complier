API_URL = "https://judge029.p.rapidapi.com/submissions"
HEADERS = {
    "x-rapidapi-key": "adfbe3a184mshb52145137acec4dp1405edjsne54330b823c0",
    "x-rapidapi-host": "judge029.p.rapidapi.com",
    "Content-Type": "application/json"
}
QUERY_STRING = {"base64_encoded": "true", "wait": "true", "fields": "*"}
