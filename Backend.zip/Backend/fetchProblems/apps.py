from django.apps import AppConfig


class FetchproblemsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fetchProblems'
